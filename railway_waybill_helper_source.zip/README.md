# 铁路运单草单审核助手 · 第一阶段

这是一个 Python + PySide6 的 Windows 本地桌面程序。第一阶段只做界面。

本次已在当前电脑的项目目录创建 `.venv` 并安装依赖。你可以直接进入该目录，执行 `.\.venv\Scripts\python.exe main.py` 启动。下面的安装步骤用于重新创建环境或在其他电脑上运行；源码压缩包不包含 `.venv`。

## 1. 项目结构与文件作用

```text
railway_waybill_helper/
├── main.py             # 程序入口，负责启动应用和显示主窗口
├── main_window.py      # 主窗口、文件选择、四个审核栏、输入预览
├── requirements.txt    # 需要安装的第三方库及版本
├── README.md           # 安装、运行、代码解释和验收步骤
└── .gitignore          # 以后使用 Git 时，忽略虚拟环境和缓存
```

只拆分“启动”和“界面”两部分，当前没有必要增加更多模块。

## 2. 准备 Python

建议使用 Windows 64 位 Python 3.12 或 3.13。

如果还没安装，可以从 [Python 官方 Windows 下载页](https://www.python.org/downloads/windows/)下载安装程序。安装时启用将 Python 加入 PATH 的选项，完成后重新打开 PowerShell。

先运行：

```powershell
python --version
```

应该看到类似 `Python 3.13.x` 的版本号。如果出现“找不到命令”，或者打开 Microsoft Store、提示无法访问 WindowsApps 下的 python.exe，说明命令没有指向可用的 Python，需要先安装 Python 或修正 PATH。这是环境问题，还没有运行到项目代码。

## 3. 安装依赖并运行

在项目文件夹内打开 PowerShell。例如，本次创建位置为：

```powershell
cd "C:\Users\ADMIN\Documents\Codex\2026-10-30\windows-python-python-pyside6-windows-exe\outputs\railway_waybill_helper"
```

首次运行时，依次执行下面三条命令：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

- 第一条：创建本项目自己的 Python 环境，依赖会装在 `.venv` 文件夹内。
- 第二条：根据依赖清单安装 PySide6，需要联网下载，可能需要几分钟。
- 第三条：使用同一个环境的 Python 启动程序。

这里直接指定虚拟环境中的解释器，不需要执行激活脚本，也不用修改 PowerShell 执行策略。`venv`、`sys` 都是 Python 自带模块，无需另外安装。

之后每次运行，只需进入项目文件夹，再执行：

```powershell
.\.venv\Scripts\python.exe main.py
```

当前唯一需要主动安装的第三方库是 `PySide6`；它依赖的 Qt 组件和 shiboken6 会由 pip 自动安装，无需单独安装 Qt。版本固定为 `6.10.1`，方便复现本阶段环境。可参考 [Qt for Python 官方安装说明](https://doc.qt.io/qtforpython-6/gettingstarted.html)。

## 4. 怎样使用和验收

1. 启动程序，确认窗口标题为“铁路运单草单审核助手”。
2. 点击“选择 PDF”，选择一个 PDF，确认对应路径显示出来。
3. 点击“选择 ZIP”，选择一个 ZIP，确认对应路径显示出来。
4. 在第3、4、23栏中输入多行审核要求，它们默认启用。
5. 第25栏默认停用。勾选“启用本栏审核”后，输入框可以填写。
6. 取消任意栏的勾选，输入框会变灰；重新勾选后，原来填写的内容仍在。
7. 点击“开始审核”，下方显示文件路径及当前启用栏的要求预览。
8. 再次打开文件选择框后点击“取消”，原有路径应保留。

PDF、ZIP 可以分别选择，也可以同时保留各一个路径；本阶段仅记录路径，不读取文件、不解压。较长路径可以在路径框内左右滚动查看，也可以复制；鼠标悬停会显示完整路径。

本阶段的输入只保留在当前窗口内，关闭程序后不会保存。“审核结果”中的内容只是输入预览，没有“通过/不通过”的审核结论。

本次使用 Windows、Python 3.12.14、PySide6 6.10.1 完成了启动、界面渲染、默认状态、中文多行输入、勾选联动、内容保留和预览检查。PDF/ZIP 路径回填及取消选择的自动检查使用了模拟对话框返回值；真实系统文件选择对话框请按上述步骤手动验收。

## 5. 关键代码怎么理解

### main.py：从这里开始读

`QApplication` 管理整个应用；`MainWindow()` 创建我们自己的窗口；`window.show()` 让窗口显示出来；`app.exec()` 开启事件循环，让程序等待并响应点击、输入、关闭等操作。

`if __name__ == "__main__":` 表示只有直接运行 `main.py` 时才启动程序。将来其他文件导入它时，不会自动弹出窗口。

### main_window.py：窗口由控件和布局组成

`MainWindow(QMainWindow)` 表示我们的主窗口继承 Qt 提供的窗口能力。`self` 表示当前这个窗口对象，比如 `self.pdf_path` 就是保存在这个窗口中的 PDF 路径输入框。

- `QPushButton`：按钮。
- `QLineEdit`：单行输入框，用于显示可复制的文件路径。
- `QCheckBox`：启用、停用复选框。
- `QPlainTextEdit`：多行纯文本框，用于填写审核要求或显示结果。
- `QGroupBox`：带标题的分组框。
- `QVBoxLayout`：把控件从上到下排列。
- `QGridLayout`：把控件按行、列排列，窗口缩放时会自动调整。

### 点击按钮为什么能执行函数

```python
self.pdf_button.clicked.connect(self.select_pdf)
```

`clicked` 是按钮发出的“点击信号”，`connect` 把信号与函数连接起来。这里写 `self.select_pdf` 而不是 `self.select_pdf()`，因为我们要让它在点击时执行，而不是创建窗口时立即执行。

### 文件选择为什么要判断路径是否为空

```python
file_path, _ = QFileDialog.getOpenFileName(...)
if file_path:
    self.pdf_path.setText(file_path)
```

文件选择框返回路径和过滤器两个值。我们只使用路径，所以用 `_` 接收另一个暂时不用的值。用户取消时路径为空，`if file_path` 可以避免覆盖原来选择的路径。

### 第25栏为什么默认停用

```python
group = self.create_review_group(number, enabled=(number != 25))
```

`number != 25` 在第25栏时为 `False`，其他栏为 `True`。创建审核栏时，这个值同时决定默认勾选状态和输入框是否可编辑。

```python
checkbox.toggled.connect(text_edit.setEnabled)
```

勾选变化会传出 `True` 或 `False`，直接交给输入框的 `setEnabled`。它只改变是否可以输入，不会删除文字。

### 为什么用字典保存四个栏

`self.review_fields` 按栏号保存复选框和文本框。点击“开始审核”时，用一个循环读取各栏的 `isChecked()` 和 `toPlainText()`，拼出预览文字。这里没有任何文本审核算法。

## 6. 遇到错误，先判断原因

先看报错最后一行确定错误类型，再看上方的文件名和行号。不要看到报错就把整份代码替换掉。

| 现象 | 常见原因与检查方法 |
| --- | --- |
| 找不到 `python`，或 WindowsApps 中的 python.exe 无法访问 | Python 尚未安装，或 PATH 指向了占位入口。先解决 `python --version`。 |
| `No module named 'PySide6'` | 当前解释器没有安装 PySide6，常见原因是安装和运行使用了不同的 Python。用同一个 `.venv\Scripts\python.exe` 安装和运行。 |
| `can't open file ... main.py` | 当前目录不对。先进入项目文件夹，确认其中有 `main.py`。 |
| `No module named 'main_window'` | `main_window.py` 缺失、被改名，或不在 `main.py` 同一文件夹。 |
| pip 下载超时或连接失败 | 依赖下载阶段的网络问题，还没有运行到界面代码。确认网络后重新执行安装命令。 |
| `No matching distribution found` | 检查 Python 版本、是否为 64 位，以及 pip 使用的包源；本项目建议使用 64 位 Python 3.12 或 3.13。 |
| `IndentationError` | Python 用缩进表示代码层级。检查报错行附近的空格，统一使用四个空格。 |

如需排查，请保留完整报错文本，以及你执行的命令。理解“在哪一步失败”，比盲目修改代码更重要。

## 7. 本阶段范围

当前没有 OCR、PDF 栏位定位、审核算法、Excel 导出、数据库、网页框架或 AI API。后续可以在本地桌面结构上继续扩展，再单独进行 Windows exe 打包；本阶段不安装打包工具。
