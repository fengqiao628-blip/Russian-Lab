"""第一阶段主窗口：选择文件、填写要求、显示输入预览。"""

from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("铁路运单草单审核助手")
        self.resize(900, 740)
        self.setMinimumSize(720, 640)

        # 用字典保存各栏的复选框和输入框，便于后面读取内容。
        self.review_fields = {}

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 16, 20, 16)
        main_layout.setSpacing(12)

        title = QLabel("铁路运单草单审核助手")
        title_font = title.font()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        main_layout.addWidget(title)
        main_layout.addWidget(QLabel("第一阶段：选择文件并填写审核要求"))

        files_group = QGroupBox("待审核文件")
        files_layout = QGridLayout(files_group)
        self.pdf_button = QPushButton("选择 PDF")
        self.zip_button = QPushButton("选择 ZIP")
        self.pdf_path = QLineEdit()
        self.zip_path = QLineEdit()
        self.pdf_path.setPlaceholderText("尚未选择 PDF 文件")
        self.zip_path.setPlaceholderText("尚未选择 ZIP 文件")
        # 路径由文件选择框填写；仍可选中、复制和左右滚动查看。
        self.pdf_path.setReadOnly(True)
        self.zip_path.setReadOnly(True)
        files_layout.addWidget(self.pdf_button, 0, 0)
        files_layout.addWidget(self.pdf_path, 0, 1)
        files_layout.addWidget(self.zip_button, 1, 0)
        files_layout.addWidget(self.zip_path, 1, 1)
        files_layout.setColumnStretch(1, 1)
        main_layout.addWidget(files_group)

        # 同一个函数创建四个相似区域，避免复制四份界面代码。
        fields_layout = QGridLayout()
        for index, number in enumerate((3, 4, 23, 25)):
            group = self.create_review_group(number, enabled=(number != 25))
            # 整除得到行号，取余得到列号，排列为两行两列。
            fields_layout.addWidget(group, index // 2, index % 2)
        fields_layout.setColumnStretch(0, 1)
        fields_layout.setColumnStretch(1, 1)
        main_layout.addLayout(fields_layout, stretch=2)

        self.start_button = QPushButton("开始审核")
        self.start_button.setMinimumHeight(36)
        main_layout.addWidget(self.start_button)

        results_group = QGroupBox("审核结果")
        results_layout = QVBoxLayout(results_group)
        self.results_text = QPlainTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setPlaceholderText(
            "此处预留审核结果。\n当前版本点击“开始审核”只显示输入预览，不执行实际审核。"
        )
        results_layout.addWidget(self.results_text)
        main_layout.addWidget(results_group, stretch=1)

        # connect 后面写函数名，不加括号：等按钮被点击时再调用。
        self.pdf_button.clicked.connect(self.select_pdf)
        self.zip_button.clicked.connect(self.select_zip)
        self.start_button.clicked.connect(self.start_review)

    def create_review_group(self, number, enabled):
        """创建一个审核栏，并设置它的默认启用状态。"""
        group = QGroupBox(f"第{number}栏审核要求")
        layout = QVBoxLayout(group)
        checkbox = QCheckBox("启用本栏审核（取消勾选即停用）")
        checkbox.setChecked(enabled)
        text_edit = QPlainTextEdit()
        text_edit.setPlaceholderText(f"请输入第{number}栏的审核要求，可填写多行……")
        text_edit.setEnabled(enabled)

        # 勾选变化时自动启用或禁用输入框；停用不会清空已经填写的文字。
        checkbox.toggled.connect(text_edit.setEnabled)
        layout.addWidget(checkbox)
        layout.addWidget(text_edit)
        self.review_fields[number] = {"checkbox": checkbox, "text_edit": text_edit}
        return group

    def select_pdf(self):
        # 返回值依次是文件路径、所选过滤器；下划线表示暂时不用的值。
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择 PDF 文件", "", "PDF 文件 (*.pdf)"
        )
        # 取消选择时路径为空，此时保留上一次选择。
        if file_path:
            self.pdf_path.setText(file_path)
            self.pdf_path.setToolTip(file_path)

    def select_zip(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择 ZIP 文件", "", "ZIP 压缩文件 (*.zip)"
        )
        if file_path:
            self.zip_path.setText(file_path)
            self.zip_path.setToolTip(file_path)

    def start_review(self):
        """仅预览当前输入；第一阶段不读取文件，也不执行审核。"""
        lines = [
            "【输入预览】当前为第一阶段界面演示，尚未执行实际审核。",
            "",
            f"PDF：{self.pdf_path.text() or '未选择'}",
            f"ZIP：{self.zip_path.text() or '未选择'}",
        ]
        for number, controls in self.review_fields.items():
            lines.append("")
            if controls["checkbox"].isChecked():
                requirement = controls["text_edit"].toPlainText().strip()
                lines.append(f"第{number}栏（启用）：")
                lines.append(requirement or "（尚未填写审核要求）")
            else:
                lines.append(f"第{number}栏：已停用")
        self.results_text.setPlainText("\n".join(lines))
